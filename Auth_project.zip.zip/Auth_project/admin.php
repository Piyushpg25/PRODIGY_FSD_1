<?php
session_start();
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}

if ($_SESSION["role"] !== "admin") {
    echo "⛔ Access Denied! Only admin can view this page.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Panel</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <button class="toggle-btn" onclick="toggleMode()">🌙 Toggle Mode</button>
  <h2>Welcome Admin 👑 <?php echo $_SESSION["username"]; ?></h2>
  <p>This is an admin-only area.</p>
  <a href="logout.php">Logout</a>

  <script>
    function toggleMode() {
      document.body.classList.toggle('dark-mode');
    }
  </script>
</body>
</html>
