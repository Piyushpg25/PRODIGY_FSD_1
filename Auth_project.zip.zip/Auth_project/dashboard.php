<?php
session_start();

// Agar user login nahi hai to login page pe redirect karo
if (!isset($_SESSION["user_id"])) {
    header("Location: login.html");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
</head>
<body>
<button class="toggle-btn" onclick="toggleMode()"> Toggle</button>
  <h2>Welcome, <?php echo $_SESSION["username"]; ?> 🎉</h2>
  <p>You are logged in successfully.</p>

  <p><strong>User Role:</strong> <?php echo $_SESSION["role"]; ?></p>

  <a href="logout.php">Logout</a>
  <script>
  function toggleMode() {
    document.body.classList.toggle('dark-mode');
    document.querySelector('form')?.classList.toggle('dark-mode');
  }
</script>

</body>
</html>
